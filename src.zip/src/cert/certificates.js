export const certificatesList = [
    {id:0,name:"cert_1",src:`https://robohash.org/${Math.random()*100}?200x200`,desc:"this certificate is about ..."},
    {id:1,name:"aws_2",src:`https://robohash.org/${Math.random()*100}?200x200`,desc:"this certificate is about ..."},
    {id:2,name:"cert_3",src:`https://robohash.org/${Math.random()*100}?200x200`,desc:"this certificate is about ..."},
    {id:3,name:"cert_4",src:`https://robohash.org/${Math.random()*100}?200x200`,desc:"this certificate is about ..."},
    {id:4,name:"cert_5",src:`https://robohash.org/${Math.random()*100}?200x200`,desc:"this certificate is about ..."},
    {id:5,name:"cert_6",src:`https://robohash.org/${Math.random()*100}?200x200`,desc:"this certificate is about ..."},
    {id:6,name:"cert_7",src:`https://robohash.org/${Math.random()*100}?200x200`,desc:"this certificate is about ..."},
    {id:7,name:"cert_8",src:`https://robohash.org/${Math.random()*100}?200x200`,desc:"this certificate is about ..."}
]